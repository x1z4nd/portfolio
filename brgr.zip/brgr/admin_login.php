<?php
session_start();

if (isset($_POST['submit'])) {
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Установите подключение к базе данных
    $servername = "localhost";
    $db_username = "root";
    $db_password = "";
    $dbname = "brgr";

    $connection = mysqli_connect($servername, $db_username, $db_password, $dbname);

    // Проверка подключения к базе данных
    if (!$connection) {
        die("Connection failed: " . mysqli_connect_error());
    }

    // Защитите от SQL-инъекций (используйте подготовленные выражения)
    $username = mysqli_real_escape_string($connection, $username);
    $password = mysqli_real_escape_string($connection, $password);

    // Проверьте учетные данные
    $query = "SELECT * FROM admins WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($connection, $query);

    // Проверка ошибок запроса
    if (!$result) {
        die("Database query failed: " . mysqli_error($connection));
    }

    // Проверка успешности входа
    if (mysqli_num_rows($result) == 1) {
        $_SESSION['admin'] = true;
        header("Location: admin_panel.php");
        exit();
    } else {
        $error_message = "Неверные учетные данные";
    }

    // Закрыть подключение к базе данных
    mysqli_close($connection);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/admin.css">
</head>
<body>
<div class="container">
            <div class="row">
                <div class="col-md-12">
                <h2>Вход в админ-панель</h2>
                    <?php if (isset($error_message)) echo "<p>$error_message</p>"; ?>
                    <form method="post" action="">
                        <label for="username">Имя пользователя:</label>
                        <input type="text" name="username" placeholder="username" required>
                        <label for="password">Пароль:</label>
                        <input type="password" placeholder="password" name="password"  required>
                        <button class="btn" type="submit" name="submit">Войти</button>
                    </form>
                </div>
            </div>
        </div> 
</body>
</html>
