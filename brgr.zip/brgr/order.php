<?php
session_start();

// Подключение к базе данных (замените данными вашей БД)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brgr";

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Проверяем, существует ли сессионная переменная для корзины
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    $message = "Ваша корзина пуста";
} else {
    $message = "Ваш заказ";
    $items = [];
    $totalPrice = 0; // Общая сумма заказа

    // Убираем дубликаты из массива $_SESSION['cart']
    $uniqueProductIds = array_unique($_SESSION['cart']);

    // Перечисляем уникальные товары в корзине
    foreach ($uniqueProductIds as $productId) {
        // Запрос к базе данных для получения информации о товаре, его категории и цене
        $sql = "SELECT d.name AS dish_name, c.name AS category_name, p.price, d.image
                FROM dishes d 
                INNER JOIN categories c ON d.id_categories = c.id_categories
                INNER JOIN price_list p ON d.id_price_list = p.id_price_list
                WHERE d.id_dishes = $productId";
        $result = $conn->query($sql);
        
        // Если запрос выполнен успешно и есть результаты
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $row['image_path'] = !empty($row['image']) ? 'images/cards/' . $row['image'] : 'images/cards/default.jpg'; // Определение пути к изображению
            $row['id_dishes'] = $productId; // Добавляем id товара в массив
            $items[] = $row;

            // Увеличиваем общую сумму заказа на цену текущего товара
            $totalPrice += $row['price'];
        } else {
            $items[] = ['dish_name' => "Товар #$productId", 'category_name' => "", 'price' => "", 'image_path' => "images/cards/default.jpg", 'id_dishes' => $productId]; // Если информация о товаре не найдена в базе данных
        }
    }
}

// Закрываем соединение с базой данных
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <style>
        .card {
            height: 100%;
        }
        .card-img-top {
            height: 300px; /* Задаем фиксированную высоту для изображений */
            object-fit: cover; /* Масштабирование изображений до заполнения всей области */
        }
    </style>
    <title>Заказ</title>
</head>
<body>
    <div class="container">
        <h1><?php echo $message; ?></h1>
        <?php if (!empty($items)): ?>
            <div class="row">
                <?php foreach ($items as $item): ?>
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <img src="<?php echo $item['image_path']; ?>" class="card-img-top" alt="...">
                            <div class="card-body">
                                <h5 class="card-title"><?php echo $item['dish_name']; ?></h5>
                                <p class="card-text"><?php echo $item['category_name']; ?></p>
                                <p class="card-text"><?php echo $item['price']; ?> руб.</p>
                            </div>
                        </div>
                    </div>
                <?php endforeach; ?>
            </div>
            <h2>Общая сумма заказа: <?php echo $totalPrice; ?> руб.</h2>
            <form action="submit_order.php" method="POST">
                <div class="form-group">
                    <label for="name">Имя</label>
                    <input type="text" class="form-control" id="name" name="name" required>
                </div>
                <div class="form-group">
                    <label for="phone">Телефон</label>
                    <input type="text" class="form-control" id="phone" name="phone" required>
                </div>
                <div class="form-group">
                    <label for="address">Адрес</label>
                    <input type="text" class="form-control" id="address" name="address" required>
                </div>
                <button type="submit" class="btn btn-primary">Заказать</button>
            </form>
        <?php else: ?>
            <p>Ваша корзина пуста</p>
        <?php endif; ?>
    </div>
</body>
</html>
