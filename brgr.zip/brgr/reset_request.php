<?php
session_start();
require_once "config.php";
require_once "PHPMailer-master/src/PHPMailer.php";
require_once "PHPMailer-master/src/SMTP.php";
require_once "PHPMailer-master/src/Exception.php";

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Функция для генерации случайного кода для подтверждения сброса пароля
function generateRandomCode($length = 6) {
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}

// Проверяем, была ли отправлена форма запроса сброса пароля
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $email = trim($_POST['email']);

    // Проверяем, существует ли пользователь с введенной электронной почтой
    $query = $db->prepare("SELECT * FROM user WHERE email = ?");
    $query->bind_param('s', $email);
    $query->execute();
    $result = $query->get_result();

    if ($result->num_rows > 0) {
        // Пользователь существует, генерируем и отправляем код подтверждения
        $verification_code = generateRandomCode(); // Функция generateRandomCode() определена в предыдущем ответе
        $_SESSION['reset_password_code'] = $verification_code;
        $_SESSION['reset_email'] = $email;

        // Отправляем код на указанную почту с использованием PHPMailer
        $mail = new PHPMailer(true);
        // Отправляем код на указанную почту с использованием PHPMailer
        $mail = new PHPMailer(true);
        $mail->SMTPDebug = SMTP::DEBUG_SERVER; // Включаем отладку SMTP
        try {
            // Настройки сервера отправки
            $mail->isSMTP();
            $mail->Host = 'smtp.gmail.com';
            $mail->SMTPAuth = true;
            $mail->Username = 'burgerclub.supp@gmail.com';
            $mail->Password = 'fbpd typt rxhj dqng ';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
            $mail->Port = 587;

            // Настройки сообщения
            $mail->setFrom('burgerclub.supp@gmail.com', 'Viktor');
            $mail->addAddress($email);
            $mail->Subject = "Код подтверждения сброса пароля";
            $mail->Body = "Ваш код подтверждения для сброса пароля: $verification_code";

            // Отправка сообщения
            $mail->send();

            // Если письмо успешно отправлено, перенаправляем пользователя на страницу ввода кода
            header("Location: reset_password.php");
            exit;
        } catch (Exception $e) {
            // Если возникла ошибка при отправке письма, выводим сообщение об ошибке
            $error = '<p class="error">Ошибка при отправке письма. Пожалуйста, попробуйте еще раз.</p>';
        }
    } else {
        // Пользователь с указанной почтой не найден, предложим создать аккаунт
        $error = '<p class="error">Пользователь с указанной электронной почтой не найден. Хотите <a href="register.php">создать аккаунт</a>?</p>';
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Request Password Reset</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/reset_request.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p>Введите свою электронную почту для запроса сброса пароля.</p>
            <?php echo isset($error) ? $error : ''; ?>
            <form action="" method="post">
                <div class="form-group">
                    <label>Email</label>
                    <input type="email" placeholder="Email" name="email" class="form-control" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary" value="Submit">Отправить код для сброса пароля</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>