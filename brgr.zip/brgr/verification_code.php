<?php
session_start();
require_once "config.php";

// Проверяем, был ли отправлен запрос с кодом подтверждения
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $email = $_SESSION['reset_email'];
    $verification_code = trim($_POST['verification_code']);

    // Проверяем, совпадает ли введенный код с сохраненным в сессии
    if ($_SESSION['reset_password_code'] == $verification_code) {
        // Код подтверждения верный, перенаправляем пользователя на страницу сброса пароля
        header("Location: reset_password.php?email=$email");
        exit;
    } else {
        $error = '<p class="error">Неверный код подтверждения. Попробуйте снова.</p>';
    }
}

// Если была отправлена форма запроса сброса пароля, сохраняем email в сессии
if (isset($_GET['email'])) {
    $_SESSION['reset_email'] = $_GET['email'];
} else {
    // Если email не был передан, перенаправляем пользователя на страницу запроса сброса пароля
    header("Location: reset_request.php");
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Verification Code</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/verification_code.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p>Введите код подтверждения, отправленный на вашу электронную почту.</p>
            <?php echo isset($error) ? $error : ''; ?>
            <form action="" method="post">
                <div class="form-group">
                    <label>Код подтверждения</label>
                    <input type="text" placeholder="Код подтверждения" name="verification_code" class="form-control" required>
                </div>
                <div class="form-group">
                    <button type="submit" name="submit" class="btn btn-primary" value="Submit">Подтвердить код</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>