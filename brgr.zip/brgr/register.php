<?php

$success = '';
$error = '';

require_once "config.php";
require_once "session.php";

// Проверяем, была ли отправлена форма
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    // Проверяем, было ли предоставлено значение для поля email
    if (!empty($_POST['email'])) {
        $email = trim($_POST['email']);
    } else {
        // Если значение для поля email не было предоставлено, добавляем сообщение об ошибке
        $error .= '<p class="error">Please enter your email address.</p>';
    }

    // Продолжаем выполнение кода только если значение для поля email было предоставлено
    if (!empty($email)) {
        $login = trim($_POST['login']);
        $password = trim($_POST['password']);
        $confirm_password = trim($_POST["confirm_password"]);
        $password_hash = password_hash($password, PASSWORD_BCRYPT);

        // Validate password
        if (strlen($password) < 8) {
            $error .= '<p class="error">Password must have at least 8 characters.</p>';
        }

        // Check for common combinations
        $common_combinations = array("123", "qwerty", "password");
        foreach ($common_combinations as $combination) {
            if (stripos($password, $combination) !== false) {
                $error .= '<p class="error">Password cannot contain common combinations like "123", "qwerty", "password", etc.</p>';
                break;
            }
        }

        // Validate confirm password
        if (empty($confirm_password)) {
            $error .= '<p class="error">Please enter confirm password.</p>';
        } else {
            if ($password != $confirm_password) {
                $error .= '<p class="error">Password did not match.</p>';
            }
        }

        // Проверяем, что ошибок нет перед выполнением запроса на вставку
        if (empty($error)) {
            // Проверяем, существует ли пользователь с таким же логином
            $checkLoginQuery = $db->prepare("SELECT * FROM user WHERE login = ?");
            $checkLoginQuery->bind_param('s', $login);
            $checkLoginQuery->execute();
            $checkLoginResult = $checkLoginQuery->get_result();
            if ($checkLoginResult->num_rows > 0) {
                $error .= '<p class="error">Такой пользователь уже существует. Попробуйте другой логин.</p>';
            } else {
                // Добавляем параметр для id_role
                $id_role = 1; // Например, предполагаем, что роль пользователя - 1

                // Подготавливаем запрос на вставку
                $insertQuery = $db->prepare("INSERT INTO user (email, login, password, id_role) VALUES (?, ?, ?, ?);");
                // Проверяем, успешно ли была подготовлена команда
                if ($insertQuery) {
                    // Привязываем параметры и выполняем запрос
                    $insertQuery->bind_param("sssi", $email, $login, $password_hash, $id_role);
                    $result = $insertQuery->execute();
                    if ($result) {
                        $success .= '<p class="success">Вы успешно зарегистрированны!</p>';
                    } else {
                        $error .= '<p class="error">Error: ' . $insertQuery->error . '</p>';
                    }
                    // Закрываем подготовленное выражение
                    $insertQuery->close();
                } else {
                    // Если подготовка запроса не удалась, добавляем сообщение об ошибке
                    $error .= '<p class="error">Error preparing SQL statement.</p>';
                }
            }
        }
    }
}

// Close DB connection
mysqli_close($db);

?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/register.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <a class="btn1" href="/index.php">Главная</a>
            <p>Заполните данную форму для создания аккаунта</p>
            <?php echo $success; ?>
            <?php echo $error; ?>
            <form action="" method="post">
                <div class="form-group">
                    <label>Электронная почта:</label> <!-- Заменили метку -->
                    <input type="text" placeholder="qwerty123@gmail.com" name="email" class="form-control" required> <!-- Заменили name и метку -->
                </div>
                <div class="form-group">
                    <label>Логин</label>
                    <input type="text" name="login" placeholder="Petya123" class="form-control" required />
                </div>
                <div class="form-group">
                    <label for="password">Пароль:</label>
                    <input type="password" id="password" placeholder="Strong password123" name="password" class="form-control" oninput="validatePassword(this.value)">
                </div>
                <div class="form-group">
                    <label for="password">Подтвердите пароль:</label>
                    <input type="password" name="confirm_password" placeholder="Strong password123" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="submit" name="submit" class="btn btn-primary" value="Регистрация">
                </div>
                <div id="passwordError" class="valida" style="color: red;"></div>

            </form>

            <p>Уже зарегистрировались? <a href="login.php">Авторизуйтесь здесь</a>.</p>
        </div>
    </div>
</div>

<script>
        function validatePassword(password) {
            var passwordError = document.getElementById("passwordError");
            var error = "";

            // Проверка на количество символов
            if (password.length < 8) {
                error += "Пароль должен содержать хотя бы 8 символов. ";
            }

            // Проверка на популярные комбинации
            var commonCombinations = ["123", "qwerty", "password"]; // Пример популярных комбинаций
            commonCombinations.forEach(function(combination) {
                if (password.toLowerCase().includes(combination)) {
                    error += "Пароль не должен содержать популярные комбинации \"" + combination + "\". ";
                }
            });

            // Отображение ошибки
            passwordError.textContent = error;
        }
    </script>
    <script>
        function validatePasswords() {
            var password = document.getElementById("password").value;
            var confirmPassword = document.getElementById("confirmPassword").value;
            var passwordError = document.getElementById("passwordError");
            var error = "";

            // Проверка на совпадение паролей
            if (password !== confirmPassword) {
                error = "Passwords do not match.";
            }

            // Отображение ошибки
            passwordError.textContent = error;
        }
    </script>

</body>
</html>