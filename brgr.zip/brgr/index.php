<?php
// Включение отображения ошибок
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();

// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brgr";

$connection = mysqli_connect($servername, $username, $password, $dbname);

// Проверка соединения
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Запрос для получения списка категорий
$category_query = "SELECT * FROM categories";
$category_result = mysqli_query($connection, $category_query);

// Проверка наличия ошибок в запросе категорий
if (!$category_result) {
    die("Database query failed: " . mysqli_error($connection));
}

// Создание пустого массива для категорий
$categories = [];
while ($category_row = mysqli_fetch_assoc($category_result)) {
    $categories[$category_row['id_categories']] = $category_row['name'];
}

// Запрос для получения блюд по категориям
$menu_query = "SELECT d.*, p.price 
               FROM dishes d 
               LEFT JOIN price_list p ON d.id_price_list = p.id_price_list 
               ORDER BY d.id_categories, d.id_dishes";
$menu_result = mysqli_query($connection, $menu_query);

// Проверка наличия ошибок в запросе блюд
if (!$menu_result) {
    die("Database query failed: " . mysqli_error($connection));
}

// Создание пустого массива для блюд
$menu = [];
while ($menu_row = mysqli_fetch_assoc($menu_result)) {
    $category_id = $menu_row['id_categories'];
    $menu[$categories[$category_id]][] = $menu_row;
}

// Проверка авторизации пользователя
$userLoggedIn = false; // Предположим, что пользователь не авторизован
if (isset($_SESSION['user_id'])) {
    $userLoggedIn = true; // Если сессионная переменная user_id существует, пользователь авторизован
}

// Получение пути к логотипу из базы данных
$query = "SELECT logo_path FROM settings WHERE id = 1"; // Предположим, что логотип хранится в таблице "settings"
$result = mysqli_query($connection, $query);

if ($result && mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
    $logo_path = $row['logo_path'];
} else {
    $logo_path = "/logo.png"; // Путь к логотипу по умолчанию
}

// Check if an image is uploaded
if (!empty($_SESSION["uploaded_image"])) {
    $uploaded_image = $_SESSION["uploaded_image"];
}

// Clear the uploaded image session variable
unset($_SESSION["uploaded_image"]);

// Получение пути к логотипу из базы данных
$query1 = "SELECT main_bg FROM bg WHERE id = 1"; // Предположим, что логотип хранится в таблице "settings"
$result1 = mysqli_query($connection, $query1);

if ($result1 && mysqli_num_rows($result1) > 0) {
    $row = mysqli_fetch_assoc($result1);
    $bg_path = $row['main_bg'];
} else {
    $bg_path = "/home-img.jpeg"; // Путь к логотипу по умолчанию
}

// Check if an image is uploaded
if (!empty($_SESSION["uploaded_bg"])) {
    $uploaded_bg = $_SESSION["uploaded_bg"];
}

// Проверка наличия запроса на поиск категории
$search_query = ""; // Установка пустого значения по умолчанию
if (isset($_GET['query'])) {
    $search_query = $_GET['query'];
    if (!empty($search_query)) {
        // Если параметр 'query' установлен и не пустой
        $search_query = mysqli_real_escape_string($connection, $search_query);

        // Поиск идентификатора категории по ее имени
        $category_id = null;

        // Запрос категории по имени
        $category_query = "SELECT id_categories FROM categories WHERE name LIKE '%$search_query%'";
        $category_result = mysqli_query($connection, $category_query);

        if ($category_result && mysqli_num_rows($category_result) > 0) {
            $category_row = mysqli_fetch_assoc($category_result);
            $category_id = $category_row['id_categories'];

            // Запрос к базе данных для поиска товаров
            $sql = "SELECT d.*, p.price 
                    FROM dishes d 
                    LEFT JOIN price_list p ON d.id_price_list = p.id_price_list 
                    WHERE d.id_categories = '$category_id'";
        }
    } else {
        // Если параметр 'query' пуст, выведите сообщение об ошибке
        echo "Ошибка: параметр 'query' пуст.";
    }
}
?>






<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>BurgerClub</title>

    <script src="/js/script.js"></script>

    <!-- jQuery -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>

    <!-- шрифт  -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">

    <!-- css  -->
    <link rel="stylesheet" href="css/style.css">


</head>

<body>


    <!-- начало шапки  -->

    <header class="header">

<a href="#" class="logo">
    <img src="<?php echo $logo_path; ?>" alt="Логотип">
    <p>BurgerClub</p>
</a>

<nav class="navbar">
    <a href="#home">Главная</a>
    <a href="#about">О нас</a>
    <a href="#menu">Меню</a>
</nav>
<div class="search">
    <form id="search-form1" action="#" method="GET">
        <div class="search-container">
            <input type="search" id="query" name="query" class="search" placeholder="Поиск..." value="<?php echo htmlspecialchars($search_query); ?>">
            <!-- Кнопка "крестик" внутри input -->
            <span id="clear-search" class="clear-icon"><i class="fas fa-times"></i></span>
        </div>
        <button type="submit" class="submitSearch"><i class="fas fa-search"></i></button>
    </form>
</div>

<div class="icons">
    <div class="fas fa-shopping-cart" id="cart-btn"  style="cursor: pointer;"></div>
    <div class="fas fa-user-tie" id="user"></div>
    <div class="fas fa-bars" id="menu-btn"></div>
</div>
</header>
    
    <div id="search-results" class="box-container"></div>


    <!-- конец шапки -->

    <!-- начало главной секции  -->

    <section class="home" id="home">

        <div class="content">
            <h3>Cочный бургер из говядины</h3>
            <p>Я бы прошел милю только ради тебя.</p>
            <a href="#order" class="btn">заказать</a>
        </div>

    </section>

    <!-- конец главной секции -->

    <!-- начало секции "о нас"  -->

    <section class="about" id="about">
        <div class="row">

            <div class="image">
                <img src="images/about-img.jpeg" alt="Изображение О нас">
            </div>

            <div class="content">
                <h3>Почему наши бургеры такие особенные?</h3>
                <p id="about_text"><br></p>
                <a href="more_about.php" class="btn">Узнать больше</a>
            </div>

        </div>

    </section>

    <!-- начало секции "меню"  -->

    <section class="menu" id="menu">
    <h1 class="heading"><span> Меню </span></h1>

    <?php
    // Получаем список категорий
    $sql_categories = "SELECT id_categories, name FROM categories";
    $result_categories = mysqli_query($connection, $sql_categories);
    if ($result_categories && mysqli_num_rows($result_categories) > 0) {
        while ($row_category = mysqli_fetch_assoc($result_categories)) {
            $category_id = $row_category['id_categories'];
            $category_name = $row_category['name'];
    ?>
            <div class="category">
                <h2>
                    <span>
                    <?php echo $category_name; ?>
                    </span>
                </h2>
                <div class="box-container">
                    <?php
                    // Получаем блюда для текущей категории
                    $sql_dishes = "SELECT d.*, p.price 
                    FROM dishes d 
                    LEFT JOIN price_list p ON d.id_price_list = p.id_price_list 
                    WHERE d.id_categories = $category_id";
                    $result_dishes = mysqli_query($connection, $sql_dishes);
                    if ($result_dishes && mysqli_num_rows($result_dishes) > 0) {
                        while ($row_dish = mysqli_fetch_assoc($result_dishes)) {
                            // Определение пути к изображению
                            $proImg = !empty($row_dish["image"]) ? 'images/cards/' . $row_dish["image"] : 'images/cards/';
                    ?>
                            <div class="box">
                                <div class="name"><?php echo $row_dish['name']; ?></div>
                                <img src="<?php echo $proImg; ?>" alt="<?php echo $row_dish['name']; ?>">
                                <div class="price-list"><?php echo $row_dish['price']; ?> ₽</div>
                                <button onclick="addToCart(<?php echo $row_dish['id_dishes']; ?>, this)" class="btn order-btn">Добавить в корзину</button>
                            </div>
                    <?php
                        }
                    } else {
                        echo "<p>Блюда отсутствуют</p>";
                    }
                    ?>
                </div>
            </div>
    <?php
        }
    } else {
        echo "<p>Категории отсутствуют</p>";
    }
    ?>
</section>
        
        <iframe class="map" id="map_908456447" sandbox="allow-modals allow-forms allow-scripts allow-same-origin allow-popups allow-top-navigation-by-user-activation" width="100%" height="500px" frameborder="0"></iframe><script type="text/javascript">(function(e,t){var r=document.getElementById(e);r.contentWindow.document.open(),r.contentWindow.document.write(atob(t)),r.contentWindow.document.close()})("map_908456447", "PGJvZHk+PHN0eWxlPgogICAgICAgIGh0bWwsIGJvZHkgewogICAgICAgICAgICBtYXJnaW46IDA7CiAgICAgICAgICAgIHBhZGRpbmc6IDA7CiAgICAgICAgfQogICAgICAgIGh0bWwsIGJvZHksICNtYXAgewogICAgICAgICAgICB3aWR0aDogMTAwJTsKICAgICAgICAgICAgaGVpZ2h0OiAxMDAlOwogICAgICAgIH0KICAgICAgICAuYnVsbGV0LW1hcmtlciB7CiAgICAgICAgICAgIHdpZHRoOiAyMHB4OwogICAgICAgICAgICBoZWlnaHQ6IDIwcHg7CiAgICAgICAgICAgIGJveC1zaXppbmc6IGJvcmRlci1ib3g7CiAgICAgICAgICAgIGJhY2tncm91bmQtY29sb3I6ICNmZmY7CiAgICAgICAgICAgIGJveC1zaGFkb3c6IDAgMXB4IDNweCAwIHJnYmEoMCwgMCwgMCwgMC4yKTsKICAgICAgICAgICAgYm9yZGVyOiA0cHggc29saWQgIzAyODFmMjsKICAgICAgICAgICAgYm9yZGVyLXJhZGl1czogNTAlOwogICAgICAgIH0KICAgICAgICAucGVybWFuZW50LXRvb2x0aXAgewogICAgICAgICAgICBiYWNrZ3JvdW5kOiBub25lOwogICAgICAgICAgICBib3gtc2hhZG93OiBub25lOwogICAgICAgICAgICBib3JkZXI6IG5vbmU7CiAgICAgICAgICAgIHBhZGRpbmc6IDZweCAxMnB4OwogICAgICAgICAgICBjb2xvcjogIzI2MjYyNjsKICAgICAgICB9CiAgICAgICAgLnBlcm1hbmVudC10b29sdGlwOmJlZm9yZSB7CiAgICAgICAgICAgIGRpc3BsYXk6IG5vbmU7CiAgICAgICAgfQogICAgICAgIC5kZy1wb3B1cF9oaWRkZW5fdHJ1ZSB7CiAgICAgICAgICAgIGRpc3BsYXk6IGJsb2NrOwogICAgICAgIH0KICAgICAgICAubGVhZmxldC1jb250YWluZXIgLmxlYWZsZXQtcG9wdXAgLmxlYWZsZXQtcG9wdXAtY2xvc2UtYnV0dG9uIHsKICAgICAgICAgICAgdG9wOiAwOwogICAgICAgICAgICByaWdodDogMDsKICAgICAgICAgICAgd2lkdGg6IDIwcHg7CiAgICAgICAgICAgIGhlaWdodDogMjBweDsKICAgICAgICAgICAgZm9udC1zaXplOiAyMHB4OwogICAgICAgICAgICBsaW5lLWhlaWdodDogMTsKICAgICAgICB9CiAgICA8L3N0eWxlPjxkaXYgaWQ9Im1hcCI+PC9kaXY+PHNjcmlwdCB0eXBlPSJ0ZXh0L2phdmFzY3JpcHQiIHNyYz0iaHR0cHM6Ly9tYXBzLmFwaS4yZ2lzLnJ1LzIuMC9sb2FkZXIuanM/cGtnPWZ1bGwmYW1wO3NraW49bGlnaHQiPjwvc2NyaXB0PjxzY3JpcHQ+KGZ1bmN0aW9uKGUpe3ZhciB0PUpTT04ucGFyc2UoZSkscj10Lm9yZGVyZWRHZW9tZXRyaWVzLG49dC5tYXBQb3NpdGlvbixhPXQuaXNXaGVlbFpvb21FbmFibGVkO2Z1bmN0aW9uIG8oZSl7cmV0dXJuIGRlY29kZVVSSUNvbXBvbmVudChhdG9iKGUpLnNwbGl0KCIiKS5tYXAoZnVuY3Rpb24oZSl7cmV0dXJuIiUiKygiMDAiK2UuY2hhckNvZGVBdCgwKS50b1N0cmluZygxNikpLnNsaWNlKC0yKX0pLmpvaW4oIiIpKX1ERy50aGVuKGZ1bmN0aW9uKCl7dmFyIGU9REcubWFwKCJtYXAiLHtjZW50ZXI6W24ubGF0LG4ubG9uXSx6b29tOm4uem9vbSxzY3JvbGxXaGVlbFpvb206YSx6b29tQ29udHJvbDohYX0pO0RHLmdlb0pTT04ocix7c3R5bGU6ZnVuY3Rpb24oZSl7dmFyIHQscixuLGEsbztyZXR1cm57ZmlsbENvbG9yOm51bGw9PT0odD1lKXx8dm9pZCAwPT09dD92b2lkIDA6dC5wcm9wZXJ0aWVzLmZpbGxDb2xvcixmaWxsT3BhY2l0eTpudWxsPT09KHI9ZSl8fHZvaWQgMD09PXI/dm9pZCAwOnIucHJvcGVydGllcy5maWxsT3BhY2l0eSxjb2xvcjpudWxsPT09KG49ZSl8fHZvaWQgMD09PW4/dm9pZCAwOm4ucHJvcGVydGllcy5zdHJva2VDb2xvcix3ZWlnaHQ6bnVsbD09PShhPWUpfHx2b2lkIDA9PT1hP3ZvaWQgMDphLnByb3BlcnRpZXMuc3Ryb2tlV2lkdGgsb3BhY2l0eTpudWxsPT09KG89ZSl8fHZvaWQgMD09PW8/dm9pZCAwOm8ucHJvcGVydGllcy5zdHJva2VPcGFjaXR5fX0scG9pbnRUb0xheWVyOmZ1bmN0aW9uKGUsdCl7cmV0dXJuInJhZGl1cyJpbiBlLnByb3BlcnRpZXM/REcuY2lyY2xlKHQsZS5wcm9wZXJ0aWVzLnJhZGl1cyk6REcubWFya2VyKHQse2ljb246ZnVuY3Rpb24oZSl7cmV0dXJuIERHLmRpdkljb24oe2h0bWw6IjxkaXYgY2xhc3M9J2J1bGxldC1tYXJrZXInIHN0eWxlPSdib3JkZXItY29sb3I6ICIrZSsiOyc+PC9kaXY+IixjbGFzc05hbWU6Im92ZXJyaWRlLWRlZmF1bHQiLGljb25TaXplOlsyMCwyMF0saWNvbkFuY2hvcjpbMTAsMTBdfSl9KGUucHJvcGVydGllcy5jb2xvcil9KX0sb25FYWNoRmVhdHVyZTpmdW5jdGlvbihlLHQpe2UucHJvcGVydGllcy5kZXNjcmlwdGlvbiYmdC5iaW5kUG9wdXAobyhlLnByb3BlcnRpZXMuZGVzY3JpcHRpb24pLHtjbG9zZUJ1dHRvbjohMCxjbG9zZU9uRXNjYXBlS2V5OiEwfSksZS5wcm9wZXJ0aWVzLnRpdGxlJiZ0LmJpbmRUb29sdGlwKG8oZS5wcm9wZXJ0aWVzLnRpdGxlKSx7cGVybWFuZW50OiEwLG9wYWNpdHk6MSxjbGFzc05hbWU6InBlcm1hbmVudC10b29sdGlwIn0pfX0pLmFkZFRvKGUpfSl9KSgneyJvcmRlcmVkR2VvbWV0cmllcyI6W3sidHlwZSI6IkZlYXR1cmUiLCJwcm9wZXJ0aWVzIjp7ImRlc2NyaXB0aW9uIjoiUEhBKzBKSFF1OUM0MExmUXV0QytJTkM2SU5DKzBZSFJndEN3MEwzUXZ0Q3kwTHJRdFR3dmNEND0iLCJzdHJva2VDb2xvciI6IiM0ZGI3MjUiLCJzdHJva2VXaWR0aCI6Miwic3Ryb2tlT3BhY2l0eSI6MSwiekluZGV4IjoxfSwiZ2VvbWV0cnkiOnsidHlwZSI6IkxpbmVTdHJpbmciLCJjb29yZGluYXRlcyI6W1szNy40OTM3MjUsNTUuODA4OTg1XSxbMzcuNDkzODkyLDU1LjgwODk1NV0sWzM3LjQ5MzgzOCw1NS44MDg4OF1dfSwiaWQiOjI2ODF9LHsidHlwZSI6IkZlYXR1cmUiLCJwcm9wZXJ0aWVzIjp7ImNvbG9yIjoiIzAyODFmMiIsInRpdGxlIjoiUWxWU1IwVlNJRU5NVlVJPSIsImRlc2NyaXB0aW9uIjoiUEhBKzBLRFF0ZEdCMFlMUXZ0R0EwTERRdlNCQ1ZWSkhSVklnUTB4VlFpRFF2ZEN3MFlYUXZ0QzAwTGpSZ3RHQjBZOGcwTC9RdmlEUXNOQzAwWURRdGRHQjBZTWdJTkN6TGlEUW5OQyswWUhRdXRDeTBMQXNJTkNTMEw3UXU5QyswTHJRdnRDNzBMRFF2TkdCMExyUXZ0QzFJTkdJMEw3UmdkR0IwTFVzSURFMUx6SXlJQzhnMFlQUXU5QzQwWWJRc0NEUW45Q3cwTDNSaE5DNDBMdlF2dEN5MExBc0lESXlQQzl3UGc9PSIsInpJbmRleCI6MTAwMDAwMDAwMH0sImdlb21ldHJ5Ijp7InR5cGUiOiJQb2ludCIsImNvb3JkaW5hdGVzIjpbMzcuNDkzODMzLDU1LjgwODg2OV19LCJpZCI6MjcyM31dLCJtYXBQb3NpdGlvbiI6eyJsYXQiOjU1LjgwODkyMzYyODc5OTA1LCJsb24iOjM3LjQ5NDcyMzIwMDc5ODA0LCJ6b29tIjoxOH0sImlzV2hlZWxab29tRW5hYmxlZCI6dHJ1ZX0nKTwvc2NyaXB0PjxzY3JpcHQgYXN5bmM9IiIgdHlwZT0idGV4dC9qYXZhc2NyaXB0IiBzcmM9Imh0dHBzOi8vd3d3Lmdvb2dsZXRhZ21hbmFnZXIuY29tL2d0YWcvanM/aWQ9VUEtMTU4ODY2MTY4LTEiPjwvc2NyaXB0PjxzY3JpcHQgdHlwZT0idGV4dC9qYXZhc2NyaXB0Ij4oZnVuY3Rpb24oZSl7ZnVuY3Rpb24gdCgpe2RhdGFMYXllci5wdXNoKGFyZ3VtZW50cyl9d2luZG93LmRhdGFMYXllcj13aW5kb3cuZGF0YUxheWVyfHxbXSx0KCJqcyIsbmV3IERhdGUpLHQoImNvbmZpZyIsZSksd2luZG93Lmd0YWc9dH0pKCdVQS0xNTg4NjYxNjgtMScpPC9zY3JpcHQ+PC9ib2R5Pg==")</script>        <div class="share">    


    <!-- конец секции "меню" -->

    <div id="registrationModal" class="modal">
    <div class="modal-content">
        <span class="close">&times;</span>
        <p>Для того чтобы сделать заказ, вам необходимо <a href="/register.php">зарегистрироваться</a>.</p>
    </div>
    </div>




    <!-- начало подвала -->

    <section class="footer">

        <div class="share">
            <a href="https://vk.com/xizand" class="fab fa-telegram-plane"></a>
            <a href="https://berpt.ru/" class="fab fa-vk"></a>
            <a href="https://vk.com/berptt" class="fab fa-youtube"></a>
        </div>

        <div class="credit"> Kursovaya rabota <span> Zimovets V.S. </span> | 2024 </div>

    </section>

    <!-- конец подвала-->

    <!-- js скрипты  -->


    <script>
        document.getElementById('cart-btn').addEventListener('click', function() {
            window.location.href = 'register.php';
        });
    </script>

    <script>
        document.getElementById("user").addEventListener("click", function() {
            window.location.href = "/register.php";
        });
    </script>
    <script>
        // Подключение к базе данных
        var xhr = new XMLHttpRequest();
        xhr.onreadystatechange = function() {
            if (this.readyState == 4 && this.status == 200) {
                // Присваивание текста элементу с id="about_text"
                document.getElementById("about_text").innerHTML = this.responseText;
            }
        };
        // Запрос к файлу, который возвращает текст "О нас"
        xhr.open("GET", "get_about_text.php", true);
        xhr.send();
    </script>

    <script>
        // Функция для обновления результатов поиска и скрытия остального контента при отправке формы
        document.getElementById("search-form1").addEventListener("submit", function(event) {
            event.preventDefault(); // Предотвращаем перезагрузку страницы при отправке формы
            search(); // Выполняем поиск
            hideOtherContent(); // Проверяем и скрываем остальной контент
        });

        // Функция для отправки запроса на сервер и обновления результатов поиска на странице
        function search() {
            var query = document.getElementById("query").value; // Получаем значение из поля ввода запроса
            var xhr = new XMLHttpRequest();
            xhr.onreadystatechange = function() {
                if (this.readyState == 4 && this.status == 200) {
                    document.getElementById("search-results").innerHTML = this.responseText; // Обновляем область результатов поиска
                    hideOtherContent(); // Проверяем и скрываем остальной контент
                }
            };
            // Отправляем запрос на сервер для выполнения поиска
            xhr.open("GET", "search.php?query=" + query, true);
            xhr.send();
        }

        // Функция для показа скрытого контента при удалении слов из поиска
        function hideOtherContent() {
            // Проверяем, были ли получены результаты поиска
            var searchResults = document.getElementById("search-results");
            if (searchResults.innerHTML.trim() !== "") {
                // Если были, скрываем остальной контент
                var otherContent = document.querySelectorAll(".home, .about, .menu, .order, .map");
                otherContent.forEach(function(element) {
                    element.style.display = "none";
                });
            } else {
                // Если результаты поиска пусты, показываем все скрытые блоки
                var hiddenContent = document.querySelectorAll(".home, .about, .menu, .order, .map");
                hiddenContent.forEach(function(element) {
                    element.style.display = "block";
                });
            }
        }

        var clearSearchButton = document.getElementById("clear-search");

        // Добавляем обработчик события для кнопки "крестик"
        clearSearchButton.addEventListener("click", function() {
            // Очищаем поле поиска
            document.getElementById("query").value = "";
            // Возвращаем скрытый контент
            var otherContent = document.querySelectorAll(".home, .about, .menu, .order, map");
            otherContent.forEach(function(element) {
                element.style.display = "block"; // Изменяем стиль на "block" для отображения скрытого контента
            });
        });
    </script>

<script>
    // Получаем ссылку на кнопку "крестик"
    var clearSearchButton = document.getElementById("clear-search");

    // Добавляем обработчик события для кнопки "крестик"
    clearSearchButton.addEventListener("click", function() {
        // Очищаем поле поиска
        document.getElementById("query").value = "";
        // Возвращаем скрытый контент
        var otherContent = document.querySelectorAll(".home, .about, .menu, .order, map");
        otherContent.forEach(function(element) {
            element.style.display = "block"; // Изменяем стиль на "block" для отображения скрытого контента
        });
        // Очищаем результаты поиска
        document.getElementById("search-results").innerHTML = "";
    });
</script>

    <script>
 function showRegistrationModal() {
        var modal = document.getElementById("registrationModal");
        modal.style.display = "block";
    }

    // Закрытие модального окна при нажатии на кнопку "закрыть"
    document.getElementsByClassName("close")[0].onclick = function() {
        var modal = document.getElementById("registrationModal");
        modal.style.display = "none";
    }

    // Закрытие модального окна при нажатии вне его области
    window.onclick = function(event) {
        var modal = document.getElementById("registrationModal");
        if (event.target == modal) {
            modal.style.display = "none";
        }
    }
    </script>

    <script>
        function addToCart(productId, button) {
            var xhr = new XMLHttpRequest();
            xhr.open("POST", "add_to_cart.php", true);
            xhr.setRequestHeader("Content-Type", "application/x-www-form-urlencoded");
            xhr.onreadystatechange = function() {
                if (xhr.readyState === 4 && xhr.status === 200) {
                    var response = JSON.parse(xhr.responseText);
                    if (response.success) {
                        button.innerText = "Перейти в корзину";
                        button.onclick = function() {
                            window.location.href = "cart.php";
                        };
                    } else {
                        console.error("Ошибка при добавлении товара в корзину");
                        if (response.error === "Пользователь не авторизован") {
                            showRegistrationModal();
                        }
                    }
                }
            };
            xhr.send("product_id=" + productId);
        }
    </script>

</body>

</html>
