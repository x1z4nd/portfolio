<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brgr";

$connection = mysqli_connect($servername, $username, $password, $dbname);

if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Получение текста "О нас" из базы данных
$result = mysqli_query($connection, "SELECT about_text FROM site_content LIMIT 1");

if ($result === false) {
    die("Query failed: " . mysqli_error($connection));
}

$row = mysqli_fetch_assoc($result);
$about_text = isset($row['about_text']) ? $row['about_text'] : "";

echo htmlspecialchars($about_text);

mysqli_close($connection);
?>
