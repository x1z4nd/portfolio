<?php
session_start();

// Подключение к базе данных (замените данными вашей БД)
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brgr";

// Создание подключения
$conn = new mysqli($servername, $username, $password, $dbname);

// Проверка соединения
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Проверяем, существует ли сессионная переменная для корзины
if (!isset($_SESSION['cart']) || empty($_SESSION['cart'])) {
    $message = "Ваша корзина пуста";
    $items = [];
    $totalPrice = 0;
} else {
    $message = "Ваша корзина";
    $items = [];
    $totalPrice = 0; // Общая сумма заказа

    // Создаем массив для хранения количества каждого товара
    $itemCounts = array_count_values($_SESSION['cart']);

    // Перечисляем уникальные товары в корзине
    foreach ($itemCounts as $productId => $count) {
        // Запрос к базе данных для получения информации о товаре, его категории и цене
        $sql = "SELECT d.name AS dish_name, c.name AS category_name, p.price, d.image
                FROM dishes d 
                INNER JOIN categories c ON d.id_categories = c.id_categories
                INNER JOIN price_list p ON d.id_price_list = p.id_price_list
                WHERE d.id_dishes = $productId";
        $result = $conn->query($sql);
        
        // Если запрос выполнен успешно и есть результаты
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $row['image_path'] = !empty($row['image']) ? 'images/cards/' . $row['image'] : 'images/cards/default.jpg'; // Определение пути к изображению
            $row['id_dishes'] = $productId; // Добавляем id товара в массив
            $row['count'] = $count; // Добавляем количество товара
            $items[] = $row;

            // Увеличиваем общую сумму заказа на цену текущего товара
            $totalPrice += $row['price'] * $count;
        } else {
            $items[] = ['dish_name' => "Товар #$productId", 'category_name' => "", 'price' => "", 'image_path' => "images/cards/default.jpg", 'id_dishes' => $productId, 'count' => $count]; // Если информация о товаре не найдена в базе данных
        }
    }
}

// Обработка запросов на изменение количества товаров
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST["action"]) && isset($_POST["item_id"])) {
    $itemId = $_POST["item_id"];
    if ($_POST["action"] == "increase") {
        $_SESSION['cart'][] = $itemId;
    } elseif ($_POST["action"] == "decrease") {
        $key = array_search($itemId, $_SESSION['cart']);
        if ($key !== false) {
            unset($_SESSION['cart'][$key]);
            // Переиндексация массива после удаления элемента
            $_SESSION['cart'] = array_values($_SESSION['cart']);
        }
    }
    
    // Пересчет общей стоимости
    $totalPrice = 0;
    $itemCounts = array_count_values($_SESSION['cart']);
    foreach ($itemCounts as $productId => $count) {
        $sql = "SELECT p.price
                FROM dishes d 
                INNER JOIN price_list p ON d.id_price_list = p.id_price_list
                WHERE d.id_dishes = $productId";
        $result = $conn->query($sql);
        if ($result && $result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $totalPrice += $row['price'] * $count;
        }
    }
    
    echo json_encode(['items' => $items, 'totalPrice' => $totalPrice]);
    exit;
}

// Закрываем соединение с базой данных
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/cart.css">
    <title>Корзина</title>
</head>
<body>
    <div class="container">
        <div class="row">
            <div class="col-md-8 mx-auto">
                <div class="cart">
                    <div class="nav_bar">
                        <div class="icon" id="home">&#xf015;</div>
                        <div class="fas fa-user-tie icon" id="user"></div>
                    </div>
                    <h1 id="cart-message"><?php echo $message; ?></h1>
                    <div id="cart-items">
                        <?php if (!empty($items)): ?>
                            <?php foreach ($items as $item): ?>
                                <div class="box">
                                    <img src='<?php echo $item['image_path']; ?>' alt=''>
                                    <p><?php echo $item['category_name']; ?></p>
                                    <p><?php echo $item['dish_name']; ?></p>
                                    <p><?php echo $item['price']; ?> руб.</p>
                                    <div class="quantity-controls">
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="item_id" value="<?php echo $item['id_dishes']; ?>">
                                            <input type="hidden" name="action" value="decrease">
                                            <button type="submit">-</button>
                                        </form>
                                        <span class="item-count"><?php echo $item['count']; ?></span>
                                        <form method="post" style="display: inline;">
                                            <input type="hidden" name="item_id" value="<?php echo $item['id_dishes']; ?>">
                                            <input type="hidden" name="action" value="increase">
                                            <button type="submit">+</button>
                                        </form>
                                    </div>
                                    <form method="post" style="display: inline;">
                                        <input type="hidden" name="item_id" value="<?php echo $item['id_dishes']; ?>">
                                        <input type="hidden" name="action" value="decrease">
                                        <button type="submit" class="fas fa-bomb delete-btn"></button>
                                    </form>
                                </div>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <h2>Скорее добавьте сюда много блюд и насладитесь их вкусом!</h2>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
            <div class="col-md-4 mx-auto">
                <div class="total-price-container">
                    <h2>Общая сумма заказа:</h2>
                    <div class="dishes-list">
                        <ul id="dishes-list">
                            <?php foreach ($items as $item): ?>
                                <li><?php echo $item['dish_name']; ?> - <?php echo $item['count']; ?> шт.</li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <p class="total-price" id="total-price"><?php echo isset($totalPrice) ? $totalPrice : 0; ?> руб.</p>
                    <button class="btn btn-primary" onclick="redirectToOrder()">Заказать</button>
                </div>
            </div>
        </div>
    </div>

    <script>
        function redirectToOrder() {
            <?php if (!empty($items)): ?>
                window.location.href = "/order.php";
            <?php else: ?>
                alert("Корзина пуста");
                window.location.href = "/loggedIndex.php#menu";
            <?php endif; ?>
        }
    </script>

    <script>
        document.getElementById("user").addEventListener("click", function() {
            window.location.href = "/welcome.php";
        });
        document.getElementById("home").addEventListener("click", function() {
            window.location.href = "/loggedIndex.php";
        });
    </script>
    <script>
    document.addEventListener("DOMContentLoaded", function() {
        document.querySelectorAll(".quantity-controls button").forEach(button => {
            button.addEventListener("click", function(event) {
                event.preventDefault();
                const form = this.closest("form");
                const formData = new FormData(form);
                
                fetch("cart.php", {
                    method: "POST",
                    body: formData
                })
                .then(response => response.json())
                .then(data => {
                    // Обновляем содержимое корзины
                    const cartItems = document.getElementById("cart-items");
                    cartItems.innerHTML = "";
                    data.items.forEach(item => {
                        const itemElement = document.createElement("div");
                        itemElement.classList.add("box");
                        itemElement.innerHTML = `
                            <img src='${item.image_path}' alt=''>
                            <p>${item.category_name}</p>
                            <p>${item.dish_name}</p>
                            <p>${item.price} руб.</p>
                            <div class="quantity-controls">
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="item_id" value="${item.id_dishes}">
                                    <input type="hidden" name="action" value="decrease">
                                    <button type="submit" class="btn btn-primary">-</button>
                                </form>
                                <span class="item-count">${item.count}</span>
                                <form method="post" style="display: inline;">
                                    <input type="hidden" name="item_id" value="${item.id_dishes}">
                                    <input type="hidden" name="action" value="increase">
                                    <button type="submit" class="btn btn-primary">+</button>
                                </form>
                            </div>
                            <form method="post" style="display: inline;">
                                <input type="hidden" name="item_id" value="${item.id_dishes}">
                                <input type="hidden" name="action" value="decrease">
                                <button type="submit" class="fas fa-bomb delete-btn"></button>
                            </form>
                        `;
                        cartItems.appendChild(itemElement);
                    });

                    // Обновляем общую сумму
                    document.getElementById("total-price").textContent = `${data.totalPrice} руб.`;
                });
            });
        });
    });
</script>

</body>
</html>
