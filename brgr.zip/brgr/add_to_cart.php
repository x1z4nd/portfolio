<?php
session_start();

if (isset($_POST['product_id'])) {
    $productId = $_POST['product_id'];

    if (!isset($_SESSION['cart'])) {
        $_SESSION['cart'] = array();
    }

    // Добавим отладочное сообщение для проверки перед добавлением товара в корзину
    echo "Идентификатор товара: " . $productId . "<br>";

    $_SESSION['cart'][] = $productId;

    // Отправляем ответ клиенту
    echo "Товар добавлен в корзину!";
} else {
    echo "Ошибка: Идентификатор товара не передан!";
}
?>
