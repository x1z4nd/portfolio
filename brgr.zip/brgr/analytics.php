<?php
session_start();

// Проверка, авторизован ли администратор
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// Подключение к базе данных
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "brgr";

$connection = mysqli_connect($servername, $db_username, $db_password, $dbname);

// Проверка подключения к базе данных
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Запрос для получения данных из таблицы "orders" и связанных таблиц
$query = "SELECT 
            orders.id_orders, 
            status.status_name, 
            payment_type.type AS payment_type, 
            discount.discount_size, 
            user.name, 
            orders.order_date, 
            orders.adress, 
            orders.comment, 
            orders.phone_number
          FROM 
            orders
          INNER JOIN status ON orders.id_status = status.id_status
          INNER JOIN payment_type ON orders.id_payment = payment_type.id_payment_type
          INNER JOIN discount ON orders.id_discount = discount.id_discount
          INNER JOIN user ON orders.id_user = user.id_user";

$result = mysqli_query($connection, $query);

// Проверка на успешность выполнения запроса
if (!$result) {
    die("Ошибка запроса: " . mysqli_error($connection));
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Получаем начальную и конечную дату из формы
    $start_date = $_POST['start_date'];
    $end_date = $_POST['end_date'];

    // Запрос для подсчета общего количества заказов за выбранный период времени
    $query_orders_count = "SELECT COUNT(*) AS total_orders FROM orders WHERE order_date BETWEEN '$start_date' AND '$end_date'";
    $result_orders_count = mysqli_query($connection, $query_orders_count);
    $row_orders_count = mysqli_fetch_assoc($result_orders_count);
    $total_orders = $row_orders_count['total_orders'];

    // Запрос для подсчета количества заказанных блюд за выбранный период времени с названиями блюд
    $query_ordered_dishes = "SELECT dishes.name AS dish_name, COUNT(orders.id_orders) AS total_ordered 
    FROM orders 
    INNER JOIN dishes ON orders.id_orders = dishes.id_dishes
    WHERE orders.order_date BETWEEN '$start_date' AND '$end_date' 
    GROUP BY dishes.id_dishes";


    $result_ordered_dishes = mysqli_query($connection, $query_ordered_dishes);

    // Проверка наличия ошибок в запросе для подсчета заказанных блюд
    if (!$result_ordered_dishes) {
        die("Ошибка запроса: " . mysqli_error($connection));
    }

    // Запрос для определения наиболее активных пользователей за выбранный период времени с их именами
    $query_popular_users = "SELECT user.name, COUNT(orders.id_user) AS total_orders 
                            FROM orders 
                            INNER JOIN user ON orders.id_user = user.id_user 
                            WHERE orders.order_date BETWEEN '$start_date' AND '$end_date' 
                            GROUP BY user.id_user 
                            ORDER BY total_orders DESC";
    $result_popular_users = mysqli_query($connection, $query_popular_users);

    // Проверка наличия ошибок в запросе для определения наиболее активных пользователей
    if (!$result_popular_users) {
        die("Ошибка запроса: " . mysqli_error($connection));
    }
}

// Запрос для получения данных из таблицы "dishes" и связанных таблиц
$query1 = "SELECT 
            dishes.id_dishes,
            dishes.name, 
            categories.name AS category_name, 
            price_list.price, 
            dishes.name AS dish_name,
            dishes.image
          FROM 
            dishes
          INNER JOIN categories ON dishes.id_categories = categories.id_categories
          INNER JOIN price_list ON dishes.id_price_list = price_list.id_price_list";

$result1 = mysqli_query($connection, $query1);

// Проверка на успешность выполнения запроса
if (!$result1) {
    die("Ошибка запроса: " . mysqli_error($connection));
}

// Запрос для получения данных из таблицы "discount"
$query_discount = "SELECT id_discount, discount_size FROM discount";
$result_discount = mysqli_query($connection, $query_discount);

// Проверка на успешность выполнения запроса
if (!$result_discount) {
    die("Ошибка запроса: " . mysqli_error($connection));
}

// Закрыть подключение к базе данных
mysqli_close($connection);
?>



<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/analytics.css">
    <title>Analytics</title>
</head>
<body>
    <aside>
    <div class="navigation">
        <a href="loggedIndex.php" class="nav">Домой</a>
        <a href="analytics.php" class="nav">Аналитика</a>
        <a href="admin_panel.php" class="nav">Изменения</a>
        <a href="feedback.php" class="nav">Отзыв</a>
        <a href="logout.php" class="nav">Выйти</a>
    </div>
    </aside>
        <div class="madeby">
            <div class="made">MADE BY <a href="https://vk.com/xizand">XIZAND</a> <br> VIKTOR ZIMOVEC</div>
        </div>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                    <h1>
                        Заказы
                    </h1>
                <div class="orders">
                    <table>
                        <tr>
                            <th>Пользователь</th>
                            <th>Номер заказа</th>
                            <th>Номер телефона</th>
                            <th>Дата заказа</th>
                            <th>Статус заказа</th>
                            <th>Адрес пользователя</th>
                            <th>Способ оплаты</th>
                            <th>Размер Скидки</th>
                            <th>Комментарий</th>
                        </tr>
                        <?php while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td><?php echo $row['name']; ?></td>
                                <td><?php echo $row['id_orders']; ?></td>
                                <td><?php echo $row['phone_number']; ?></td>
                                <td><?php echo $row['order_date']; ?></td>
                                <td><?php echo $row['status_name']; ?></td>
                                <td><?php echo $row['adress']; ?></td>
                                <td><?php echo $row['payment_type']; ?></td>
                                <td><?php echo $row['discount_size']; ?></td>
                                <td><?php echo $row['comment']; ?></td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>
                <h1>Статистика</h1>
                <div class="stat">
                    <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
                        <label for="start_date">Начальная дата:</label>
                        <input type="date" id="start_date" name="start_date">
                        
                        <label for="end_date">Конечная дата:</label>
                        <input type="date" id="end_date" name="end_date">
                        
                        <button type="submit" class="btn">Показать статистику</button>
                    </form>

                    <?php if ($_SERVER["REQUEST_METHOD"] == "POST") { ?>
                        <!-- Вывод статистики -->
                        <h2>Общее количество заказов за этот период:</h2>
                        <p><?php echo $total_orders; ?></p>

                        <h2>Наиболее заказываемые блюда за этот период:</h2>
                        <ul>
                            <?php while ($row_ordered_dishes = mysqli_fetch_assoc($result_ordered_dishes)) { ?>
                                <li><?php echo "Блюдо: " . $row_ordered_dishes['dish_name'] . ", Количество заказов: " . $row_ordered_dishes['total_ordered']; ?></li>
                            <?php } ?>
                        </ul>

                        <h2>Наиболее активные пользователи за этот период:</h2>
                        <ul>
                            <?php while ($row_popular_users = mysqli_fetch_assoc($result_popular_users)) { ?>
                                <li><?php echo "Пользователь: " . $row_popular_users['name'] . ", Количество заказов: " . $row_popular_users['total_orders']; ?></li>
                            <?php } ?>
                        </ul>
                    <?php } ?>
                </div>
            <h1>Блюда</h1>
            <div class="dishes">
                    <table>
                        <tr>
                            <th>Номер блюда</th>
                            <th>Категория</th>
                            <th>Цена</th>
                            <th>Название блюда</th>
                            <th>Изображение</th>
                        </tr>
                        <?php while ($row1 = mysqli_fetch_assoc($result1)) { ?>
                            <tr>
                                <td><?php echo $row1['id_dishes']; ?></td>
                                <td><?php echo $row1['category_name']; ?></td>
                                <td><?php echo $row1['price']; ?>₽</td>
                                <td><?php echo $row1['dish_name']; ?></td>
                                <td><img src="images/cards/<?php echo $row1['image']; ?>" alt="Изображение блюда"></td>
                            </tr>
                        <?php } ?>
                    </table>
                </div>
                <h1>Скидки</h1>
            <div class="discounts">
                <table>
        <thead>
            <tr>
                <th>Номер скидки</th>
                <th>Размер скидки</th>
            </tr>
        </thead>
        <tbody>
            <?php
            // Проверка наличия данных
            if (mysqli_num_rows($result_discount) > 0) {
                // Вывод данных в виде строк таблицы
                while ($row = mysqli_fetch_assoc($result_discount)) {
                    echo "<tr>";
                    echo "<td>" . $row["id_discount"] . "</td>";
                    echo "<td>" . $row["discount_size"] . "</td>";
                    echo "</tr>";
                }
            } else {
                echo "<tr><td colspan='2'>Нет данных</td></tr>";
            }
            ?>
        </tbody>
    </table>
    </div>
            </div>
        </div>
    </div>
</body>
</html>