<?php
// Подключение к базе данных и файлу конфигурации
require_once "config.php";

// Функция для генерации случайного кода для подтверждения сброса пароля
function generateRandomCode($length = 6) {
    return substr(str_shuffle("0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ"), 0, $length);
}

// Проверяем, был ли отправлен запрос на сброс пароля
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $new_password = trim($_POST['new_password']);
    $confirm_password = trim($_POST["confirm_password"]);
    $email = trim($_POST['email']);
    $verification_code = trim($_POST['verification_code']);

    // Валидация нового пароля
    $error = '';
    if (strlen($new_password) < 8) {
        $error .= '<p class="error">Password must have at least 8 characters.</p>';
    }

    // Проверяем, совпадают ли введенные пароли
    if ($new_password != $confirm_password) {
        $error .= '<p class="error">Passwords do not match.</p>';
    }

    // Проверяем, был ли введен верный код подтверждения
    if ($_SESSION['reset_password_code'] !== $verification_code) {
        $error .= '<p class="error">Incorrect verification code.</p>';
    }

    if (empty($error)) {
        // Хэшируем новый пароль
        $password_hash = password_hash($new_password, PASSWORD_BCRYPT);

        // Обновляем пароль пользователя в базе данных
        $updateQuery = $db->prepare("UPDATE user SET password = ? WHERE email = ?");
        $updateQuery->bind_param("ss", $password_hash, $email);
        $result = $updateQuery->execute();

        if ($result) {
            // Пароль успешно обновлен
            $success = '<p class="success">Your password has been successfully reset.</p>';
        } else {
            // Ошибка при обновлении пароля
            $error = '<p class="error">Error resetting password. Please try again later.</p>';
        }
        $updateQuery->close();
    }
}

// Закрываем подключение к базе данных
mysqli_close($db);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Reset Password</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/reset_password.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <p>Введите новый пароль для вашей учетной записи.</p>
            <?php echo isset($error) ? $error : ''; ?>
            <?php echo isset($success) ? $success : ''; ?>
            <form action="" method="post">
                <div class="form-group">
                    <label>Новый пароль</label>
                    <input type="password" placeholder="Новый пароль" name="new_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Подтвердите новый пароль</label>
                    <input type="password" placeholder="Подтвердите пароль" name="confirm_password" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>Введите код подтверждения</label>
                    <input type="text" placeholder="Verification Code" name="verification_code" class="form-control" required>
                </div>
                <div class="form-group">
                    <input type="hidden" name="email" value="<?php echo isset($_GET['email']) ? $_GET['email'] : ''; ?>">
                    <button type="submit" name="submit" class="btn btn-primary" value="Submit">Сбросить пароль</button>
                </div>
            </form>
        </div>
    </div>
</div>
</body>
</html>