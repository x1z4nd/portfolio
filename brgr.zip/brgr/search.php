<?php
// Подключение к базе данных
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "brgr";

$connection = mysqli_connect($servername, $username, $password, $dbname);

// Проверка соединения
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Проверка наличия запроса поиска
if (isset($_GET['query'])) {
    $search_query = mysqli_real_escape_string($connection, $_GET['query']);

    // Запрос к базе данных для поиска
    $sql = "SELECT d.*, p.price FROM dishes d JOIN price_list p ON d.id_price_list = p.id_price_list WHERE name LIKE '%$search_query%'";
    $result = mysqli_query($connection, $sql);

    // Вывод результатов поиска в виде карточек блюд
    if ($result && mysqli_num_rows($result) > 0) {
        while ($row = mysqli_fetch_assoc($result)) {
            // Формирование HTML-разметки карточки блюда
            echo '<div class="box">';
            echo '<div class="name">' . $row['name'] . '</div>';
            echo '<img src="images/cards/' . $row['image'] . '" alt="' . $row['name'] . '">';
            echo '<div class="price-list">' . $row['price'] . ' ₽</div>';
            echo '<a href="#" class="btn">Заказать</a>';
            echo '</div>';
        }
    } else {
        echo "<p>По вашему запросу ничего не найдено.</p>"; // Выводим сообщение об отсутствии результатов
    }
} else {
    // Здесь можно разместить остальные блоки контента страницы
}
// Закрытие соединения с базой данных
mysqli_close($connection);
?>
