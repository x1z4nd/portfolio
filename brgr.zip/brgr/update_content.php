<?php
session_start();

// Проверка, авторизован ли администратор
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// Подключение к базе данных
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "brgr";

$connection = mysqli_connect($servername, $db_username, $db_password, $dbname);

// Проверка подключения к базе данных
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Обновление текста "О нас"
if (isset($_POST['update_about_text'])) {
    updateAboutText($connection);
}

// Обновление цен в меню
if (isset($_POST['update_menu'])) {
    updateMenuPrices($connection);
}

// Закрыть подключение к базе данных
mysqli_close($connection);

// Функция для обновления текста "О нас"
function updateAboutText($connection) {
    if (isset($_POST['about_text'])) {
        $about_text = mysqli_real_escape_string($connection, $_POST['about_text']);

        // Подготовка запроса
        $sql = "UPDATE site_content SET about_text = ? LIMIT 1";
        $stmt = mysqli_prepare($connection, $sql);

        // Привязка параметров
        mysqli_stmt_bind_param($stmt, "s", $about_text);

        // Выполнение запроса
        if (mysqli_stmt_execute($stmt)) {
            echo "Текст 'О нас' успешно обновлен.";
        } else {
            error_log("Ошибка при обновлении текста 'О нас': " . mysqli_error($connection));
            echo "Произошла ошибка. Пожалуйста, обратитесь к администратору сайта.";
        }
        
        // Закрытие запроса
        mysqli_stmt_close($stmt);
    }
}

// Функция для обновления цен в меню
function updateMenuPrices($connection) {
    if (isset($_POST['item_prices']) && is_array($_POST['item_prices'])) {
        foreach ($_POST['item_prices'] as $id => $price) {
            $id = mysqli_real_escape_string($connection, $id);
            $price = mysqli_real_escape_string($connection, $price);

            // Подготовка запроса для получения названия блюда
            $sql_name = "SELECT name FROM dishes WHERE id = ?";
            $stmt_name = mysqli_prepare($connection, $sql_name);
            mysqli_stmt_bind_param($stmt_name, "i", $id);
            mysqli_stmt_execute($stmt_name);
            mysqli_stmt_bind_result($stmt_name, $name);
            mysqli_stmt_fetch($stmt_name);

            // Подготовка запроса
            $sql = "UPDATE dishes SET price = ? WHERE id = ?";
            $stmt = mysqli_prepare($connection, $sql);

            // Привязка параметров
            mysqli_stmt_bind_param($stmt, "di", $price, $id);

            // Выполнение запроса
            if (mysqli_stmt_execute($stmt)) {
                echo "Цена блюда \"$name\" успешно обновлена.";
            } else {
                error_log("Ошибка при обновлении цены блюда \"$name\": " . mysqli_error($connection));
                echo "Произошла ошибка. Пожалуйста, обратитесь к администратору сайта.";
            }

            // Закрытие запросов
            mysqli_stmt_close($stmt_name);
            mysqli_stmt_close($stmt);
        }
    }
}
?>
