<?php
header("Cache-Control: no-store, no-cache, must-revalidate, max-age=0");
header("Pragma: no-cache");
header("Expires: Sat, 26 Jul 1997 05:00:00 GMT");

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once "config.php";
require_once "session.php";

ob_start();

// start the session (если его еще нет)
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

$error = '';
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {

    if (isset($_POST['login']) && isset($_POST['password'])) {
        // Здесь ваш код обработки логина и пароля
        $login = $_POST['login'];
        $password = $_POST['password'];
    
    

    // validate if login is empty
    if (empty($login)) {
        $error .= '<p class="error">Пожалуйста введите логин.</p>';
    }

    // validate if password is empty
    if (empty($password)) {
        $error .= '<p class="error">Пожалуйста введите пароль.</p>';
    }

    if (empty($error)) {
        if ($query = $db->prepare("SELECT * FROM user WHERE login = ?")) {
            $query->bind_param('s', $login);
            $query->execute();
            $result = $query->get_result();

        if ($result->num_rows > 0) {
            $row = $result->fetch_assoc();
            $_SESSION["user"] = $row;
    if (password_verify($password, $row['password'])) {
        if (isset($_SESSION["user"]["id"])) {
                        // Теперь вы можете безопасно использовать $_SESSION["user"]["id"]
                        $userid = $_SESSION["user"]["id"];
                        // Далее ваш код...
                    }

                // Redirect the user to welcome page
                echo '<script>window.location.href = "welcome.php";</script>';
                exit;

                } else {
                    $error .= '<p class="error">Пароль неверен.</p>';
                }
            } 
                else {
                $error .= '<p class="error">Пользователя с таким логином не существует.</p>';
            }
        }
        $query->close();
    }
}
    // Close connection
    mysqli_close($db);
}

ob_end_flush();
?>

<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="UTF-8">
        <title>Login</title>
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
        <link rel="stylesheet" href="/css/login.css">
    </head>
<body>
<div class="container">
            <div class="row">
                <div class="col-md-12">
                <a class="btn1" href="/loggedIndex.php">Главная</a>
                    <p>Пожалуйста, введите логин и пароль.</p>
                    <?php echo $error; ?>
                    <form action="" method="post">
                        <div class="form-group">
                            <label>Логин</label>
                            <input type="text" placeholder="Petya123" name="login" class="form-control" required />
                        </div>    
                        <div class="form-group">
                            <label>Пароль</label>
                            <input type="password" placeholder="Strong password123" name="password" class="form-control" required>
                        </div>
                        <div class="form-group">
                            <button type="submit" name="submit" class="btn btn-primary" value="Submit">Авторизация</button>
                        </div>
                        <p>Забыли пароль? <a href="reset_request.php">Восстановить пароль</a>.</p>
                        <p>Нет аккаунта? <a href="register.php"> Зарегистрируйтесь тут</a>.</p>
                    </form>
                </div>
            </div>
        </div> 
    </div>  
    </body>
</html>