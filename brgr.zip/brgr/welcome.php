<?php

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Start the session
session_start();

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome <?php echo isset($_SESSION["user"]["name"]) ? $_SESSION["user"]["login"] : ''; ?></title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="css/welcome.css">
</head>
<body>
<div class="container">
    <div class="row">
        <div class="col-md-12">
            <div class="profile">
                <div class="profile_information">
                    <img class="profile-picture" src="images/uploads/default-avatar.png" alt="User Profile Picture">
                    <h1>Привет, <strong><?php echo isset($_SESSION["user"]["login"]) ? $_SESSION["user"]["login"] : ''; ?></strong>! добро пожаловать на наш сайт.</h1>
                    <p class="profile-bio">
                        На нашем сайте ресторана вы можете заказать <br>
                        много интересных сочетаний вкусов в одном блюде. <br>
                        В ассортименте нашего меню есть различные основные
                        блюда, <br> гарниры, а также напитки, которые наши повара
                        готовят с любовью и заботой, <br> Чтобы вы были чуточку счастливее!
                    </p>
                </div>
                <div class="nav_bar">
                    <a class="nav_l" href="/loggedIndex.php">Главная</a>
                    <a class="nav_l" href="/cart.php">Корзина</a>
                    <a class="nav_l" href="#menu">Заказы</a>
                </div>
                <p>
                    <a href="logout.php" class="btn" role="button" aria-pressed="true">Выйти из аккаунта :(</a>
                </p>
            </div>
        </div>
    </div>
</div>
</body>
</html>