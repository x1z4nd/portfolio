<?php
session_start();

// Проверка, авторизован ли администратор
if (!isset($_SESSION['admin'])) {
    header("Location: admin_login.php");
    exit();
}

// Подключение к базе данных
$servername = "localhost";
$db_username = "root";
$db_password = "";
$dbname = "brgr";

$connection = mysqli_connect($servername, $db_username, $db_password, $dbname);

// Проверка подключения к базе данных
if (!$connection) {
    die("Connection failed: " . mysqli_connect_error());
}

// Обновление цены в меню
if (isset($_POST['update_price'])) {
    $item_id = mysqli_real_escape_string($connection, $_POST['item_id']);
    $new_price = mysqli_real_escape_string($connection, $_POST['new_price']);

    // Подготовка запроса для получения названия блюда
    $sql_name = "SELECT name FROM dishes WHERE id_dishes = ?";
    $stmt_name = mysqli_prepare($connection, $sql_name);

    if ($stmt_name) {
        mysqli_stmt_bind_param($stmt_name, "i", $item_id);
        mysqli_stmt_execute($stmt_name);
        mysqli_stmt_bind_result($stmt_name, $name);
        mysqli_stmt_fetch($stmt_name);

        // Закрытие запроса для получения названия блюда
        mysqli_stmt_close($stmt_name);

        // Подготовка запроса для обновления цены и даты
        $sql_update = "UPDATE price_list SET price = ?, last_updated = CURRENT_TIMESTAMP WHERE id_dishes = ?";
        $stmt_update = mysqli_prepare($connection, $sql_update);

        if ($stmt_update) {
            mysqli_stmt_bind_param($stmt_update, "di", $new_price, $item_id);

            // Выполнение запроса для обновления цены и даты
            if (mysqli_stmt_execute($stmt_update)) {
                $_SESSION['update_message'] = "Цена блюда \"$name\" успешно обновлена.";
            } else {
                $_SESSION['update_message'] = "Ошибка при обновлении цены блюда \"$name\": " . mysqli_error($connection);
            }

            // Закрытие запроса для обновления цены и даты
            mysqli_stmt_close($stmt_update);
        } else {
            $_SESSION['update_message'] = "Ошибка при подготовке запроса: " . mysqli_error($connection);
        }
    } else {
        $_SESSION['update_message'] = "Ошибка при подготовке запроса: " . mysqli_error($connection);
    }
}

$result = mysqli_query($connection, "SELECT about_text FROM changes LIMIT 1");

// Проверка успешности запроса
if ($result === false) {
    die("Query failed: " . mysqli_error($connection));
}

$row = mysqli_fetch_assoc($result);
$about_text = isset($row['about_text']) ? $row['about_text'] : ""; // Убедиться, что переменная $about_text определена

// Получение данных о блюдах из базы данных
$sql_items = "SELECT * FROM dishes";
$result_items = mysqli_query($connection, $sql_items);
$items = [];
if ($result_items && mysqli_num_rows($result_items) > 0) {
    while ($row_item = mysqli_fetch_assoc($result_items)) {
        $items[] = $row_item;
    }
} else {
    $_SESSION['update_message'] = "Нет данных для отображения.";
}


// Обработка загрузки файла (изображения логотипа)
if (isset($_FILES['logo_image'])) {
    // Путь для сохранения загруженных изображений
    $upload_dir = "images/";

    // Генерация уникального имени файла
    $file_name = uniqid() . '_' . $_FILES['logo_image']['name'];

    // Полный путь к файлу на сервере
    $target_path = $upload_dir . $file_name;

    // Загрузка файла на сервер
    if (move_uploaded_file($_FILES['logo_image']['tmp_name'], $target_path)) {
        // Сохранение пути к изображению в базе данных
        $sql = "UPDATE settings SET logo_path='$target_path' WHERE id=1";
        if (mysqli_query($connection, $sql)) {
            $_SESSION['update_message'] = "Логотип успешно обновлен.";
        } else {
            $_SESSION['update_message'] = "Ошибка при обновлении логотипа: " . mysqli_error($connection);
        }
    } else {
        $_SESSION['update_message'] = "Ошибка при загрузке логотипа.";
    }

    // Перенаправление на ту же страницу после обработки загрузки
    header("Location: {$_SERVER['PHP_SELF']}");
    exit();
}

// Обработка загрузки файла (изображения логотипа)
if (isset($_FILES1['bg_image'])) {
    // Путь для сохранения загруженных изображений
    $upload_dir1 = "images/";

    // Генерация уникального имени файла
    $file_name1 = uniqid() . '_' . $_FILES1['bg_image']['name'];

    // Полный путь к файлу на сервере
    $target_path1 = $upload_dir1 . $file_name1;

    // Загрузка файла на сервер
    if (move_uploaded_file($_FILES1['bg_image']['tmp_name'], $target_path1)) {
        // Сохранение пути к изображению в базе данных
        $sql1 = "UPDATE bg SET main_bg='$target_path1' WHERE id=1";
        if (mysqli_query($connection, $sql1)) {
            $_SESSION['update_message'] = "Фон успешно обновлен.";
        } else {
            $_SESSION['update_message'] = "Ошибка при обновлении фона: " . mysqli_error($connection);
        }
    } else {
        $_SESSION['update_message'] = "Ошибка при загрузке фона.";
    }

    // Перенаправление на ту же страницу после обработки загрузки
    header("Location: {$_SERVER['PHP_SELF']}");
    exit();
}

// Обновление цены в меню
if (isset($_POST['update_price'])) {
    // Код для обновления цены остается без изменений

    // Код обработки обновления цены...
}

// Получение существующих скидок из базы данных
$query2 = "SELECT * FROM discount";
$result2 = mysqli_query($connection, $query2);

// Проверка успешности запроса
if (!$result2) {
    die("Ошибка запроса: " . mysqli_error($connection));
}

// Обработка добавления новой скидки
if (isset($_POST['add_discount'])) {
    $new_discount_size = mysqli_real_escape_string($connection, $_POST['new_discount_size']);

    // Добавление новой скидки в базу данных
    $query_add_discount = "INSERT INTO discount (discount_size) VALUES ('$new_discount_size')";

    if (mysqli_query($connection, $query_add_discount)) {
        $_SESSION['update_message'] = "Новая скидка успешно добавлена.";
    } else {
        $_SESSION['update_message'] = "Ошибка при добавлении скидки: " . mysqli_error($connection);
    }
}

// Обработка обновления размера скидки
if (isset($_POST['update_discount'])) {
    $discount_id = mysqli_real_escape_string($connection, $_POST['discount_id']);
    $updated_discount_size = mysqli_real_escape_string($connection, $_POST['updated_discount_size']);

    // Обновление размера скидки в базе данных
    $query_update_discount = "UPDATE discount SET discount_size = '$updated_discount_size' WHERE id_discount = $discount_id";

    if (mysqli_query($connection, $query_update_discount)) {
        $_SESSION['update_message'] = "Размер скидки успешно изменен.";
    } else {
        $_SESSION['update_message'] = "Ошибка при изменении размера скидки: " . mysqli_error($connection);
    }
}

// Получение списка скидок из базы данных
$query_discounts = "SELECT * FROM discount";
$result_discounts = mysqli_query($connection, $query_discounts);

// // Проверяем наличие параметра id в URL
// if (isset($_GET['id'])) {
//     $dish_id = $_GET['id'];
    
//     // Если форма отправлена, обновляем информацию о блюде
//     if ($_SERVER["REQUEST_METHOD"] == "POST") {
//         $new_dish_name = $_POST['dish_name'];
//         $new_category_id = $_POST['category_id'];
//         $new_price = $_POST['price'];

//         // Обновляем информацию о блюде в базе данных
//         $query_update_dish = "UPDATE dishes SET name = '$new_dish_name', id_categories = $new_category_id, price = $new_price WHERE id_dishes = $dish_id";
//         $result_update_dish = mysqli_query($connection, $query_update_dish);

//         // Проверка на успешность выполнения запроса
//         if ($result_update_dish) {
//             echo "Информация о блюде успешно обновлена.";
//             // Перезагрузка страницы для отображения обновленной информации
//             echo "<meta http-equiv='refresh' content='0'>";
//         } else {
//             echo "Ошибка при обновлении информации о блюде: " . mysqli_error($connection);
//         }
//     }

//     // Получаем информацию о блюде из базы данных
//     $query_dish_info = "SELECT * FROM dishes WHERE id_dishes = $dish_id";
//     $result_dish_info = mysqli_query($connection, $query_dish_info);

//     // Проверка на успешность выполнения запроса
//     if (!$result_dish_info) {
//         die("Ошибка запроса: " . mysqli_error($connection));
//     }

//     $dish_info = mysqli_fetch_assoc($result_dish_info);
    
// } else {
//     // Если параметр id не указан, выводим сообщение об ошибке
//     echo "Идентификатор блюда не указан.";
// }




    // Закрыть подключение к базе данных
    mysqli_close($connection);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Panel</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
    <link rel="stylesheet" href="/css/adminP.css">
    <!-- Ваши стили -->
</head>
<body>
<aside>
<div class="navigation">
        <a href="loggedIndex.php" class="nav">Домой</a>
        <a href="analytics.php" class="nav">Аналитика</a>
        <a href="admin_panel.php" class="nav">Изменения</a>
        <a href="feedback.php" class="nav">Отзыв</a>
        <a href="logout.php" class="nav">Выйти</a>
</div>
</aside>

            <div class="madeby">
                <div class="made">MADE BY <a href="https://vk.com/xizand">XIZAND</a> <br> VIKTOR ZIMOVEC</div>
            </div>

<div class="container">
    <div class="row">
        <div class="col-md-12">
            <h2>Админ-панель</h2>
            <h3>Выберите логотип</h3>
                <div class="logoUpdate">
                    <form id="logo_form" enctype="multipart/form-data" method="POST">
                        <input type="file" name="logo_image" id="logo_image" accept="images/*">
                        <br>
                    <input type="submit" class="btnU" value="Обновить Логотип">
                </form>
            </div>

            <!-- Форма для загрузки изображения -->
            <form action="" method="post" enctype="multipart/form-data">
                <label for="image">Выберите изображение для загрузки:</label>
                <input type="file" name="bg_image" id="bg_image" accept="images/*">
                <input type="submit" value="Загрузить изображение" name="submit">
            </form>

            <!-- Отображение загруженного изображения -->
            <?php if (isset($_SESSION["uploaded_image"])) : ?>
                <img src="<?php echo $_SESSION["uploaded_image"]; ?>" alt="Uploaded Image">
            <?php endif; ?>

            <!-- Сообщение об успешной загрузке или об ошибке -->
            <?php if (isset($_SESSION["upload_message"])) : ?>
                <p><?php echo $_SESSION["upload_message"]; ?></p>
                <?php unset($_SESSION["upload_message"]); ?>
            <?php endif; ?>

            <h3>Редактирование текста</h3>
            <form method="post" action="update_content.php" class="about">
                <label for="about_text">Текст "О нас":</label>
                <textarea name="about_text" rows="1" cols="20" placeholder="    About text"><?php echo htmlspecialchars($about_text); ?></textarea>
                <button type="submit" class="btn12" name="update_about_text">Сохранить</button>
            </form>

            <div class="update_message">
                <!-- Вывод сообщений об успешном или неудачном обновлении -->
                    <?php if (isset($_SESSION['update_message'])): ?>
                        <p><?php echo $_SESSION['update_message']; ?></p>
                    <?php unset($_SESSION['update_message']); ?>
                <?php endif; ?>
            </div>

 <!-- Форма для отображения и изменения цены -->
 <h3>Редактирование цены</h3>
            <form method="post" action="admin_panel.php" class="dish">
                <label for="item_id">Выберите блюдо:</label>
                <select name="item_id">
                    <?php foreach ($items as $item): ?>
                        <option value="<?php echo $item['id_dishes']; ?>"><?php echo $item['name']; ?></option>
                    <?php endforeach; ?>
                </select><br>
                <label for="new_price">Новая цена:</label>
                <input type="text" name="new_price" placeholder="    Price"><br>
                <button class="btn" type="submit" name="update_price">Изменить цену</button>
            </form>
            

            <!-- Форма для добавления новой скидки -->
            <h2>Добавить скидку</h2>
            <div class="discount">
            <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <label for="new_discount_size">Размер скидки:</label>
                    <input type="text" name="new_discount_size" id="new_discount_size">
                    <button type="submit" name="add_discount" class="btn">Добавить</button>
                </form>
                </div>
                <h2>Изменить скидку</h2>
                <div class="discount">
                    <!-- Форма для изменения существующей скидки -->
                    
                    <form method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>">
                    <label for="discount_id">Выберите скидку:</label>
                <select name="discount_id" id="discount_id">
                    <?php mysqli_data_seek($result2, 0); ?>
                    <?php while ($row2 = mysqli_fetch_assoc($result2)) { ?>
                        <option value="<?php echo $row2['id_discount']; ?>"><?php echo $row2['discount_size']; ?></option>
                    <?php } ?>
                </select>
                <label for="updated_discount_size">Новый размер скидки:</label>
                <input type="text" name="updated_discount_size" id="updated_discount_size">
                <button type="submit" class="btn">Изменить</button>
                </div>
                </form>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
</body>
</html>